function Accordion({ items }) {
  return <div />;
}

export default Accordion;
