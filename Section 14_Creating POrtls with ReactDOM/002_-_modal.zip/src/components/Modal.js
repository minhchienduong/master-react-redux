function Modal() {
  return <div>modal!</div>;
}

export default Modal;
