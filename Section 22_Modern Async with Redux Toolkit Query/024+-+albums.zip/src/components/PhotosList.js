function PhotosList({ album }) {
  return 'PhotosList';
}

export default PhotosList;
