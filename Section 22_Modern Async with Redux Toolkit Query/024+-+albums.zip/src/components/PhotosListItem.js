function PhotosListItem() {
  return 'PhotosListItem';
}

export default PhotosListItem;
