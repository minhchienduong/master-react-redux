function Button() {
  return <button>Hi there!</button>;
}

export default Button;
