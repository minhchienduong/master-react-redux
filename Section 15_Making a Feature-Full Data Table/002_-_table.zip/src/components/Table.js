function Table({ data }) {
  return <div>{data.length}</div>;
}

export default Table;
