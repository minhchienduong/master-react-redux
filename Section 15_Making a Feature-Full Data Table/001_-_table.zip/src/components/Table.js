function Table() {
  return <div>Table</div>;
}

export default Table;
