import Table from '../components/Table';

function TablePage() {
  return (
    <div>
      <Table />
    </div>
  );
}

export default TablePage;
