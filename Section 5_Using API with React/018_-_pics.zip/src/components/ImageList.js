function ImageList({ images }) {
  return <div>ImageList: {images.length}</div>;
}

export default ImageList;
