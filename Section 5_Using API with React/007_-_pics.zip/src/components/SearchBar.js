function SearchBar() {
  return <div>SearchBar</div>;
}

export default SearchBar;
