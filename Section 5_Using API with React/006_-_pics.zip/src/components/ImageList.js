function ImageList() {
  return <div>ImageList</div>;
}

export default ImageList;
