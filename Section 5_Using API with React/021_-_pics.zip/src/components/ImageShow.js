function ImageShow({ image }) {
  return <div>{image.alt_description}</div>;
}

export default ImageShow;
