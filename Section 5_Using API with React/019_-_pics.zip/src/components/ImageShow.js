function ImageShow({ image }) {
  return <div>{image.id}</div>;
}

export default ImageShow;
