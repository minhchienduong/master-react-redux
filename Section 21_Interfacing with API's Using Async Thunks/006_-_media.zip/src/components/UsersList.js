function UsersList() {
  return 'Users List';
}

export default UsersList;
