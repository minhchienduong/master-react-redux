import type { Place } from "../api/Place";

export default function Map() {
  return <div>Map!!</div>;
}
