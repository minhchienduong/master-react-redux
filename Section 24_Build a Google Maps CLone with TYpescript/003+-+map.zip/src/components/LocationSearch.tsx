export default function LocationSearch() {
  return <div>Search for a location!</div>;
}
