export default function DetailsPage() {
  return <div>Details Page</div>;
}
