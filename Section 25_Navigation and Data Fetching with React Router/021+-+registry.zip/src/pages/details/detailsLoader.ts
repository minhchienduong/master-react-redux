export async function detailsLoader() {
  console.log("hi!");

  return "data!!";
}
