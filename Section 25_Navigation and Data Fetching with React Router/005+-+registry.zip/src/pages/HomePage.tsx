export default function HomePage() {
  return <div>Home Page</div>;
}
