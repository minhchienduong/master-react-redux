import type { PackageSummary } from "../types/packageSummary";

export async function searchPackages(): Promise<PackageSummary[]> {}
