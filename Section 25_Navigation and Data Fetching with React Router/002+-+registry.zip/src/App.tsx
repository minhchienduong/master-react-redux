function App() {
  return <div>Hi there!</div>;
}

export default App;
