export default function SearchPage() {
  return <div>Search Page</div>;
}
