function BookCreate() {
  return <div>BookCreate</div>;
}

export default BookCreate;
