function App() {
  return <h1>Bye there!</h1>;
}

export default App;
